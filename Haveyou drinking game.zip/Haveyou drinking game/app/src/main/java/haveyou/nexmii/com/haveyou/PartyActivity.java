package haveyou.nexmii.com.haveyou;

import android.content.Intent;
import android.graphics.Typeface;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.ImageButton;
import android.widget.TextView;

import org.w3c.dom.Text;

import java.util.Random;

public class PartyActivity extends AppCompatActivity {

    private TextView textPartyName1, textPartyName2, textPartyName3, textPartyName4, textPartyName5,
            textPartyName6, textPartyName7, textPartyName8, textPartyName9;

    //textPartyName1, textPartyName2, textPartyName3, textPartyName4, textPartyName5, textPartyName6,
    //textPartyName7, textPartyName8, textPartyName9,
    //----------------------------------------------------------------------------------------------

    private Button mainBtnQuestion;
    private ImageButton mrRefresha;
    private TextView questionTextView;
    private TextView lepartyyy;

    private Button partyGuide;
    Intent partyGuideIntent;

    final String[] partyQuestions = {

            "broken something, like a window, and ran away?",
            "went sky diving, bungee jumping, or para-sailing?",
            "talked on the phone for more than two hours?",
            "gotten lost in an amusement park or on vacation?",
            "had a friend who shared the same birthday as you?",
            "been out in the rain and really enjoyed it?",
            "had something embarrassing happen to you?",
            "had a near-death experience?",
            "gotten in trouble at school or at church?",
            "helped someone who was in danger?",
            "worn the same underwear two days in a row?",
            "drank soda pop, laughed, and had it come out your nose?",
            "regifted something that you received as a gift?",
            "went camping in a tent?",
            "had your cell phone ring at an embarrassing moment ?",
            "sung karaoke, or did a lip-sync song?",
            "seen a human baby, or a baby animal be born?",
            "had to get stitches?",
            "paid for a stranger’s meal or drink, without them knowing it was you?",
            "stayed in your pajamas all day long?",
            "climbed a tree, or went up on a roof and couldn’t get down?",
            "done a belly-flop off a diving board?",
            "held a butterfly or another insect in your hand?",
            "found a wallet or a money that someone dropped?",
            "ridden a ride that made you scream with fear?",
            "lied to get something cheaper than it was?",
            "won a contest and received a prize?",
            "talked your way out of getting in trouble?",
            "taken a picture of your face on a Xerox machine?",
            "seen an actual tornado (not on TV or in a movie)?",
            "been water skiing or snow skiing?",
            "met a famous person or a celebrity?",
            "bet on something",
            "driven drunk",
            "been screamed at by a customer at my job",
            "spent a night in the woods with no shelter",
            "texted for four hours straight",
            "Been in a drunk tank",
            "had a physical fight with my best friend",
            "sung karaoke in front of people",
            "shot a gun",
            "had someone slap me in the face",
            "been awake for two days straight",
            "accidentally said “I love you” to someone",
            "had a surprise party thrown for me",
            "Refused a kiss",
            "hitchhiked",
            "set my or someone else’s hair on fire on purpose",
            "Sneaked into a party",
            "Kissed my best friend",
            "pressured someone into getting a tattoo or piercing",
            "Smoked weed",
            "jumped from a roof",
            "Woken up drunk the next day",
            "Kissed someone of the same sex",
            "Said an “I love you” without feeling it",
            "Entered into Facebook while drunk"

    };

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_party);
        //------------------------------------------------------------------------------------------
        mainBtnQuestion = (Button) findViewById(R.id.buttonHaveYou);
        mrRefresha = (ImageButton) findViewById(R.id.refreshButtonId);
        questionTextView = (TextView) findViewById(R.id.textView5);
        //------------------------------------------------------------------------------------------


        partyGuide = (Button) findViewById(R.id.howToParty);
        lepartyyy = (TextView) findViewById(R.id.partyTitle);
        textPartyName1 = (TextView) findViewById(R.id.partyName1);
        textPartyName2 = (TextView) findViewById(R.id.partyName2);
        textPartyName3 = (TextView) findViewById(R.id.partyName3);
        textPartyName4 = (TextView) findViewById(R.id.partyName4);
        textPartyName5 = (TextView) findViewById(R.id.partyName5);
        textPartyName6 = (TextView) findViewById(R.id.partyName6);
        textPartyName7 = (TextView) findViewById(R.id.partyName7);
        textPartyName8 = (TextView) findViewById(R.id.partyName8);
        textPartyName9 = (TextView) findViewById(R.id.partyName9);

        Bundle partyExtras = getIntent().getExtras();
        String textParty1 = partyExtras.getString("partyPlayer1");
        String textParty2 = partyExtras.getString("partyPlayer2");
        String textParty3 = partyExtras.getString("partyPlayer3");
        String textParty4 = partyExtras.getString("partyPlayer4");
        String textParty5 = partyExtras.getString("partyPlayer5");
        String textParty6 = partyExtras.getString("partyPlayer6");
        String textParty7 = partyExtras.getString("partyPlayer7");
        String textParty8 = partyExtras.getString("partyPlayer8");
        String textParty9 = partyExtras.getString("partyPlayer9");

        textPartyName1.setText(textParty1);
        textPartyName2.setText(textParty2);
        textPartyName3.setText(textParty3);
        textPartyName4.setText(textParty4);
        textPartyName5.setText(textParty5);
        textPartyName6.setText(textParty6);
        textPartyName7.setText(textParty7);
        textPartyName8.setText(textParty8);
        textPartyName9.setText(textParty9);

        //------------------------------------------------------------------------------------------
        //font
        Typeface myTypefaza = Typeface.createFromAsset(getAssets(), "coolfont.ttf");
        textPartyName1.setTypeface(myTypefaza);
        textPartyName2.setTypeface(myTypefaza);
        textPartyName3.setTypeface(myTypefaza);
        textPartyName4.setTypeface(myTypefaza);
        textPartyName5.setTypeface(myTypefaza);
        textPartyName6.setTypeface(myTypefaza);
        textPartyName7.setTypeface(myTypefaza);
        textPartyName8.setTypeface(myTypefaza);
        textPartyName9.setTypeface(myTypefaza);
        lepartyyy.setTypeface(myTypefaza);
        questionTextView.setTypeface(myTypefaza);
        mainBtnQuestion.setTypeface(myTypefaza);
        partyGuide.setTypeface(myTypefaza);
        //------------------------------------------------------------------------------------------

        mainBtnQuestion.setOnClickListener(new View.OnClickListener(){

            @Override
            public void onClick(View v) {

                Random mrRandom = new Random();

                int partyRandomNumber = mrRandom.nextInt(partyQuestions.length);

                questionTextView.setText(partyQuestions[partyRandomNumber]);

            }
        });

        mrRefresha.setOnClickListener(new View.OnClickListener(){

            @Override
            public void onClick(View v) {

                Restart();

            }
        });

//----TO INSTRUCTIONS-------------------------------------------------------------------------------

        partyGuide.setOnClickListener(new View.OnClickListener(){

            @Override
            public void onClick(View v) {

                partyGuideIntent = new Intent(PartyActivity.this,InstructionsActivity.class);
                startActivity(partyGuideIntent);

            }
        });


//---------------------------------ORI'S CHUNK------------------------------------------------------

        for(int i = 1; i <= 9; i++){
            String index = Integer.toString(i);
            TextView name = (TextView) findViewByName("partyName" + index);
            Button b = (Button) findViewByName("partyCounterButton" + index);
            TextView counter = (TextView) findViewByName("ptTextCounter" + index);
            counter.setTypeface(myTypefaza);


            if (name.length() > 0) {

                b.setOnClickListener(new ClickListener());

            }else if(name.length() == 0) {

                b.setVisibility(View.INVISIBLE);
                counter.setVisibility(View.INVISIBLE);

            }
        }
    }

    class ClickListener implements View.OnClickListener {
        int partyCounter = 0;

        @Override
        public void onClick(View v) {
            partyCounter++;

            int id = v.getId();
            String name = getResources().getResourceName(id);

            String index = name.substring(name.length()-1);

            TextView tv = (TextView) findViewByName("ptTextCounter" + index);
            tv.setText(String.valueOf(partyCounter));
        }
    }

    View findViewByName(String name) {
        int resID = getResources().getIdentifier(name, "id", getPackageName());
        return findViewById(resID);
    }

//--------------------------------------------------------------------------------------------------

    public void Restart() {

        this.recreate();

    }
}
