package haveyou.nexmii.com.haveyou;

import android.content.Intent;
import android.graphics.Typeface;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.TextView;


public class CategorieActivity extends AppCompatActivity {

    private TextView name1TextView, name2TextView, name3TextView, name4TextView, name5TextView,
    name6TextView, name7TextView, name8TextView, name9TextView;
    private Button funnyButton;
    private Button partyButton;
    private Button naughtyButton;
    Intent funnyButtonIntent;
    Intent partyButtonIntent;
    Intent naughtyButtonIntent;
    private TextView title;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_categorie);

        Bundle playersExtras = getIntent().getExtras();

        final String player1Name = playersExtras.getString("player1Name");
        final String player2Name = playersExtras.getString("player2Name");
        final String player3Name = playersExtras.getString("player3Name");
        final String player4Name = playersExtras.getString("player4Name");
        final String player5Name = playersExtras.getString("player5Name");
        final String player6Name = playersExtras.getString("player6Name");
        final String player7Name = playersExtras.getString("player7Name");
        final String player8Name = playersExtras.getString("player8Name");
        final String player9Name = playersExtras.getString("player9Name");

        title = (TextView) findViewById(R.id.textView3);
        name1TextView = (TextView) findViewById(R.id.Name1);
        name2TextView = (TextView) findViewById(R.id.Name2);
        name3TextView = (TextView) findViewById(R.id.Name3);
        name4TextView = (TextView) findViewById(R.id.Name4);
        name5TextView = (TextView) findViewById(R.id.Name5);
        name6TextView = (TextView) findViewById(R.id.Name6);
        name7TextView = (TextView) findViewById(R.id.Name7);
        name8TextView = (TextView) findViewById(R.id.Name8);
        name9TextView = (TextView) findViewById(R.id.Name9);

        name1TextView.setText(player1Name);
        name2TextView.setText(player2Name);
        name3TextView.setText(player3Name);
        name4TextView.setText(player4Name);
        name5TextView.setText(player5Name);
        name6TextView.setText(player6Name);
        name7TextView.setText(player7Name);
        name8TextView.setText(player8Name);
        name9TextView.setText(player9Name);

        //----------------------------MENU BUTTONS--------------------------------------------------
        funnyButton = (Button) findViewById(R.id.buttonMenu1);
        partyButton = (Button) findViewById(R.id.buttonMenu2);
        naughtyButton = (Button) findViewById(R.id.buttonMenu3);

        funnyButton.setOnClickListener(new View.OnClickListener(){

            @Override
            public void onClick(View v) {



                funnyButtonIntent = new Intent(CategorieActivity.this, FunnyActivity.class);
                funnyButtonIntent.putExtra("funnyPlayer1", player1Name);
                funnyButtonIntent.putExtra("funnyPlayer2", player2Name);
                funnyButtonIntent.putExtra("funnyPlayer3", player3Name);
                funnyButtonIntent.putExtra("funnyPlayer4", player4Name);
                funnyButtonIntent.putExtra("funnyPlayer5", player5Name);
                funnyButtonIntent.putExtra("funnyPlayer6", player6Name);
                funnyButtonIntent.putExtra("funnyPlayer7", player7Name);
                funnyButtonIntent.putExtra("funnyPlayer8", player8Name);
                funnyButtonIntent.putExtra("funnyPlayer9", player9Name);
                startActivity(funnyButtonIntent);


            }
        });

        partyButton.setOnClickListener(new View.OnClickListener(){

            @Override
            public void onClick(View v) {

                partyButtonIntent = new Intent(CategorieActivity.this, PartyActivity.class);
                partyButtonIntent.putExtra("partyPlayer1", player1Name);
                partyButtonIntent.putExtra("partyPlayer2", player2Name);
                partyButtonIntent.putExtra("partyPlayer3", player3Name);
                partyButtonIntent.putExtra("partyPlayer4", player4Name);
                partyButtonIntent.putExtra("partyPlayer5", player5Name);
                partyButtonIntent.putExtra("partyPlayer6", player6Name);
                partyButtonIntent.putExtra("partyPlayer7", player7Name);
                partyButtonIntent.putExtra("partyPlayer8", player8Name);
                partyButtonIntent.putExtra("partyPlayer9", player9Name);
                startActivity(partyButtonIntent);
            }
        });

        naughtyButton.setOnClickListener(new View.OnClickListener(){

            @Override
            public void onClick(View v) {

                naughtyButtonIntent = new Intent(CategorieActivity.this, NaughtyActivity.class);
                naughtyButtonIntent.putExtra("naughtyPlayer1", player1Name);
                naughtyButtonIntent.putExtra("naughtyPlayer2", player2Name);
                naughtyButtonIntent.putExtra("naughtyPlayer3", player3Name);
                naughtyButtonIntent.putExtra("naughtyPlayer4", player4Name);
                naughtyButtonIntent.putExtra("naughtyPlayer5", player5Name);
                naughtyButtonIntent.putExtra("naughtyPlayer6", player6Name);
                naughtyButtonIntent.putExtra("naughtyPlayer7", player7Name);
                naughtyButtonIntent.putExtra("naughtyPlayer8", player8Name);
                naughtyButtonIntent.putExtra("naughtyPlayer9", player9Name);
                startActivity(naughtyButtonIntent);

            }
        });

        Typeface catTypeFace = Typeface.createFromAsset(getAssets(), "coolfont.ttf");

        // Font-------------------------------------------------------------------------------------
        name1TextView.setTypeface(catTypeFace);
        name2TextView.setTypeface(catTypeFace);
        name3TextView.setTypeface(catTypeFace);
        name4TextView.setTypeface(catTypeFace);
        name5TextView.setTypeface(catTypeFace);
        name6TextView.setTypeface(catTypeFace);
        name7TextView.setTypeface(catTypeFace);
        name8TextView.setTypeface(catTypeFace);
        name9TextView.setTypeface(catTypeFace);
        title.setTypeface(catTypeFace);
        funnyButton.setTypeface(catTypeFace);
        partyButton.setTypeface(catTypeFace);
        naughtyButton.setTypeface(catTypeFace);
        //------------------------------------------------------------------------------------------



    }
}
