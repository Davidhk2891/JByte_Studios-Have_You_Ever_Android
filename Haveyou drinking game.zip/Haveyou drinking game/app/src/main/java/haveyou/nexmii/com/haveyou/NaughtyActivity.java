package haveyou.nexmii.com.haveyou;

import android.content.Intent;
import android.graphics.Typeface;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.ImageButton;
import android.widget.TextView;

import org.w3c.dom.Text;

import java.util.Random;



public class NaughtyActivity extends AppCompatActivity {

    private TextView textNaughtyName1, textNaughtyName2, textNaughtyName3, textNaughtyName4, textNaughtyName5,
            textNaughtyName6, textNaughtyName7, textNaughtyName8, textNaughtyName9;

    private Button mainButtonQuestion;
    private ImageButton mrRefreshement;
    private TextView questionTextView;
    private TextView nastyTitle;
    private Button naughtyGuide;
    Intent naughtyGuideIntent;

    //-----Counters---------------------------------------------------------------------------------
    private Button naughtyButton1;
    private Button naughtyButton2;
    private Button naughtyButton3;
    private Button naughtyButton4;
    private Button naughtyButton5;
    private Button naughtyButton6;
    private Button naughtyButton7;
    private Button naughtyButton8;
    private Button naughtyButton9;
    //--------------------------------
    private TextView naughtyTextView1;
    private TextView naughtyTextView2;
    private TextView naughtyTextView3;
    private TextView naughtyTextView4;
    private TextView naughtyTextView5;
    private TextView naughtyTextView6;
    private TextView naughtyTextView7;
    private TextView naughtyTextView8;
    private TextView naughtyTextView9;
    //----------------------------------------------------------------------------------------------
    //textNaughtyName1, textNaughtyName2, textNaughtyName3, textNaughtyName4, textNaughtyName5,
    //textNaughtyName6, textNaughtyName7, textNaughtyName8, textNaughtyName9,
    //----------------------------------------------------------------------------------------------

    final String[] naughtyQuestions = {

            "showered with someone of the opposite sex?",
            "taken a pregnancy test?",
            "lied about your age?",
            "been hit on by someone who was too old?",
            "worn special clothes to cover up a hickey?",
            "spent the night sleeping by the toilet?",
            "sunbathed partially or totally naked?",
            "had sex with a person whose name you didn’t know",
            "gone “commando” (without wearing underwear)?",
            "fooled around with someone outside in nature?",
            "skinny-dipped?",
            "told someone their zipper was down or their shirt was popping open?",
            "been caught fooling around by a parent or a sibling?",
            "fooled around in a sleeping bag?",
            "got arrested?",
            "not been able to remembered how you got somewhere?",
            "cheated on a test or an exam?",
            "stuck out your tongue at the ATM camera?",
            "used a fake I.D. and then couldn’t remember your new name?",
            "burped while you were kissing someone?",
            "smoked in the high school bathroom?",
            "gotten so sick, that you swore off a particular food or type of alcohol?",
            "played strip poker?",
            "put someone’s hand in warm water to see if it would make them pee?",
            "been snuck into a bar or a movie because you were underage?",
            "had sex in the back seat of a car, or the back of a truck?",
            "been frisked by police or by airport personnel?",
            "hidden cigarettes or weed, so your parents wouldn’t know you were smoking?",
            "had a dream about a teacher or someone you work with?",
            "gotten a tatoo?",
            "fooled around in a photo taking booth?",
            "lied about your birthday just to get a free dessert?",
            "bought sexy underwear and wore it?",
            "been fooling around in a car and accidently honked the horn?",
            "broken something at a friend’s house and then not told them",
            "snooped through a friend’s bathroom or bedroom",
            "Shoplifted",
            "said family member is dying as an excuse",
            "bungee jumped",
            "had a crush on a friend’s parent",
            "Done something I regret",
            "Wanted to fall in love with my sibling’s friend",
            "Made love with someone from the university",
            "Stop remembering my first love",
            "Illegally taken something across the border",
            "Done pictures in underwear",
            "snuck into a movie",
            "stolen something from a restaurant",
            "Stuck gum under a desk",
            "Got drunk playing these games",
            "Been with the former love of my best friend",
            "Swam naked in a pool / beach",
            "Been unfaithful",
            "cheated on a test",
            "dined and dashed",
            "Gone to the bathroom and then not wash my hands",
            "Fall in love with anyone through the internet",
            "Escaped from class",
            "Lied in this game",
            "Lied to a friend to avoid a greater evil",
            "doubted in my heterosexuality",
            "experimented to see my sexual orientation",
            "looked through someone else’s phone without permission"

    };

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_naughty);
        //------------------------------------------------------------------------------------------
        mainButtonQuestion = (Button) findViewById(R.id.buttonHaveYou);
        mrRefreshement = (ImageButton) findViewById(R.id.refreshButtonId);
        questionTextView = (TextView) findViewById(R.id.textView5);
        //------------------------------------------------------------------------------------------
        naughtyGuide = (Button) findViewById(R.id.howToNaughty);
        nastyTitle = (TextView) findViewById(R.id.partyTitle);
        textNaughtyName1 = (TextView) findViewById(R.id.naughtyName1);
        textNaughtyName2 = (TextView) findViewById(R.id.naughtyName2);
        textNaughtyName3 = (TextView) findViewById(R.id.naughtyName3);
        textNaughtyName4 = (TextView) findViewById(R.id.naughtyName4);
        textNaughtyName5 = (TextView) findViewById(R.id.naughtyName5);
        textNaughtyName6 = (TextView) findViewById(R.id.naughtyName6);
        textNaughtyName7 = (TextView) findViewById(R.id.naughtyName7);
        textNaughtyName8 = (TextView) findViewById(R.id.naughtyName8);
        textNaughtyName9 = (TextView) findViewById(R.id.naughtyName9);

        Bundle naughtyExtras = getIntent().getExtras();
        String naughtyText1 = naughtyExtras.getString("naughtyPlayer1");
        String naughtyText2 = naughtyExtras.getString("naughtyPlayer2");
        String naughtyText3 = naughtyExtras.getString("naughtyPlayer3");
        String naughtyText4 = naughtyExtras.getString("naughtyPlayer4");
        String naughtyText5 = naughtyExtras.getString("naughtyPlayer5");
        String naughtyText6 = naughtyExtras.getString("naughtyPlayer6");
        String naughtyText7 = naughtyExtras.getString("naughtyPlayer7");
        String naughtyText8 = naughtyExtras.getString("naughtyPlayer8");
        String naughtyText9 = naughtyExtras.getString("naughtyPlayer9");

        textNaughtyName1.setText(naughtyText1);
        textNaughtyName2.setText(naughtyText2);
        textNaughtyName3.setText(naughtyText3);
        textNaughtyName4.setText(naughtyText4);
        textNaughtyName5.setText(naughtyText5);
        textNaughtyName6.setText(naughtyText6);
        textNaughtyName7.setText(naughtyText7);
        textNaughtyName8.setText(naughtyText8);
        textNaughtyName9.setText(naughtyText9);


        mainButtonQuestion.setOnClickListener(new View.OnClickListener(){

            @Override
            public void onClick(View v) {

                Random mrRandomy = new Random();

                int naughtyRandomNumber = mrRandomy.nextInt(naughtyQuestions.length);

                questionTextView.setText(naughtyQuestions[naughtyRandomNumber]);

            }
        });

        mrRefreshement.setOnClickListener(new View.OnClickListener(){

            @Override
            public void onClick(View v) {

                Restart();

            }
        });

//--------------------------------------------------------------------------------------------------

        naughtyButton1 = (Button) findViewById(R.id.naughtyCounterButton1);
        naughtyButton2 = (Button) findViewById(R.id.naughtyCounterButton2);
        naughtyButton3 = (Button) findViewById(R.id.naughtyCounterButton3);
        naughtyButton4 = (Button) findViewById(R.id.naughtyCounterButton4);
        naughtyButton5 = (Button) findViewById(R.id.naughtyCounterButton5);
        naughtyButton6 = (Button) findViewById(R.id.naughtyCounterButton6);
        naughtyButton7 = (Button) findViewById(R.id.naughtyCounterButton7);
        naughtyButton8 = (Button) findViewById(R.id.naughtyCounterButton8);
        naughtyButton9 = (Button) findViewById(R.id.naughtyCounterButton9);
        //----------------------------------------------------------------------
        naughtyTextView1 = (TextView) findViewById(R.id.naughtyTextCounter1);
        naughtyTextView2 = (TextView) findViewById(R.id.naughtyTextCounter2);
        naughtyTextView3 = (TextView) findViewById(R.id.naughtyTextCounter3);
        naughtyTextView4 = (TextView) findViewById(R.id.naughtyTextCounter4);
        naughtyTextView5 = (TextView) findViewById(R.id.naughtyTextCounter5);
        naughtyTextView6 = (TextView) findViewById(R.id.naughtyTextCounter6);
        naughtyTextView7 = (TextView) findViewById(R.id.naughtyTextCounter7);
        naughtyTextView8 = (TextView) findViewById(R.id.naughtyTextCounter8);
        naughtyTextView9 = (TextView) findViewById(R.id.naughtyTextCounter9);

//--------------------------------------------------------------------------------------------------

//----TO INSTRUCTIONS-------------------------------------------------------------------------------

        naughtyGuide.setOnClickListener(new View.OnClickListener(){

            @Override
            public void onClick(View v) {

                naughtyGuideIntent = new Intent(NaughtyActivity.this,InstructionsActivity.class);
                startActivity(naughtyGuideIntent);

            }
        });


//--N-1---------------------------------------------------------------------------------------------

        if (textNaughtyName1.length() > 0) {

            naughtyButton1.setOnClickListener(new View.OnClickListener(){
                int nuaghtyCounter = 0;
                @Override
                public void onClick(View v) {

                    nuaghtyCounter++;
                    naughtyTextView1.setText(String.valueOf(nuaghtyCounter));

                }
            });

        }else if(textNaughtyName1.length() == 0){

            naughtyButton1.setVisibility(View.INVISIBLE);
            naughtyTextView1.setVisibility(View.INVISIBLE);

        }
//--------------------------------------------------------------------------------------------------

//--N-2---------------------------------------------------------------------------------------------

        if (textNaughtyName2.length() > 0) {

            naughtyButton2.setOnClickListener(new View.OnClickListener(){
                int nuaghtyCounter = 0;
                @Override
                public void onClick(View v) {

                    nuaghtyCounter++;
                    naughtyTextView2.setText(String.valueOf(nuaghtyCounter));

                }
            });

        }else if(textNaughtyName2.length() == 0){

            naughtyButton2.setVisibility(View.INVISIBLE);
            naughtyTextView2.setVisibility(View.INVISIBLE);

        }
//--------------------------------------------------------------------------------------------------

//--N-3---------------------------------------------------------------------------------------------

        if (textNaughtyName3.length() > 0) {

            naughtyButton3.setOnClickListener(new View.OnClickListener(){
                int nuaghtyCounter = 0;
                @Override
                public void onClick(View v) {

                    nuaghtyCounter++;
                    naughtyTextView3.setText(String.valueOf(nuaghtyCounter));

                }
            });

        }else if(textNaughtyName3.length() == 0){

            naughtyButton3.setVisibility(View.INVISIBLE);
            naughtyTextView3.setVisibility(View.INVISIBLE);

        }
//--------------------------------------------------------------------------------------------------

//--N-4---------------------------------------------------------------------------------------------

        if (textNaughtyName4.length() > 0) {

            naughtyButton4.setOnClickListener(new View.OnClickListener(){
                int nuaghtyCounter = 0;
                @Override
                public void onClick(View v) {

                    nuaghtyCounter++;
                    naughtyTextView4.setText(String.valueOf(nuaghtyCounter));

                }
            });

        }else if(textNaughtyName4.length() == 0){

            naughtyButton4.setVisibility(View.INVISIBLE);
            naughtyTextView4.setVisibility(View.INVISIBLE);

        }
//--------------------------------------------------------------------------------------------------

//--N-5---------------------------------------------------------------------------------------------

        if (textNaughtyName5.length() > 0) {

            naughtyButton5.setOnClickListener(new View.OnClickListener(){
                int nuaghtyCounter = 0;
                @Override
                public void onClick(View v) {

                    nuaghtyCounter++;
                    naughtyTextView5.setText(String.valueOf(nuaghtyCounter));

                }
            });

        }else if(textNaughtyName5.length() == 0){

            naughtyButton5.setVisibility(View.INVISIBLE);
            naughtyTextView5.setVisibility(View.INVISIBLE);

        }
//--------------------------------------------------------------------------------------------------

//--N-6---------------------------------------------------------------------------------------------

        if (textNaughtyName6.length() > 0) {

            naughtyButton6.setOnClickListener(new View.OnClickListener(){
                int nuaghtyCounter = 0;
                @Override
                public void onClick(View v) {

                    nuaghtyCounter++;
                    naughtyTextView6.setText(String.valueOf(nuaghtyCounter));

                }
            });

        }else if(textNaughtyName6.length() == 0){

            naughtyButton6.setVisibility(View.INVISIBLE);
            naughtyTextView6.setVisibility(View.INVISIBLE);

        }
//--------------------------------------------------------------------------------------------------

//--N-7---------------------------------------------------------------------------------------------

        if (textNaughtyName7.length() > 0) {

            naughtyButton7.setOnClickListener(new View.OnClickListener(){
                int nuaghtyCounter = 0;
                @Override
                public void onClick(View v) {

                    nuaghtyCounter++;
                    naughtyTextView7.setText(String.valueOf(nuaghtyCounter));

                }
            });

        }else if(textNaughtyName7.length() == 0){

            naughtyButton7.setVisibility(View.INVISIBLE);
            naughtyTextView7.setVisibility(View.INVISIBLE);

        }
//--------------------------------------------------------------------------------------------------

//--N-8---------------------------------------------------------------------------------------------

        if (textNaughtyName8.length() > 0) {

            naughtyButton8.setOnClickListener(new View.OnClickListener(){
                int nuaghtyCounter = 0;
                @Override
                public void onClick(View v) {

                    nuaghtyCounter++;
                    naughtyTextView8.setText(String.valueOf(nuaghtyCounter));

                }
            });

        }else if(textNaughtyName8.length() == 0){

            naughtyButton8.setVisibility(View.INVISIBLE);
            naughtyTextView8.setVisibility(View.INVISIBLE);

        }
//--------------------------------------------------------------------------------------------------

//--N-9---------------------------------------------------------------------------------------------

        if (textNaughtyName9.length() > 0) {

            naughtyButton9.setOnClickListener(new View.OnClickListener(){
                int nuaghtyCounter = 0;
                @Override
                public void onClick(View v) {

                    nuaghtyCounter++;
                    naughtyTextView9.setText(String.valueOf(nuaghtyCounter));

                }
            });

        }else if(textNaughtyName9.length() == 0){

            naughtyButton9.setVisibility(View.INVISIBLE);
            naughtyTextView9.setVisibility(View.INVISIBLE);

        }
//--------------------------------------------------------------------------------------------------

        //------------------------------------------------------------------------------------------
        //Fonts
        Typeface naughtyTypeface = Typeface.createFromAsset(getAssets(), "coolfont.ttf");
        nastyTitle.setTypeface(naughtyTypeface);
        questionTextView.setTypeface(naughtyTypeface);
        mainButtonQuestion.setTypeface(naughtyTypeface);
        naughtyGuide.setTypeface(naughtyTypeface);
        textNaughtyName1.setTypeface(naughtyTypeface);
        textNaughtyName2.setTypeface(naughtyTypeface);
        textNaughtyName3.setTypeface(naughtyTypeface);
        textNaughtyName4.setTypeface(naughtyTypeface);
        textNaughtyName5.setTypeface(naughtyTypeface);
        textNaughtyName6.setTypeface(naughtyTypeface);
        textNaughtyName7.setTypeface(naughtyTypeface);
        textNaughtyName8.setTypeface(naughtyTypeface);
        textNaughtyName9.setTypeface(naughtyTypeface);
        //--------------------------------------------
        naughtyTextView1.setTypeface(naughtyTypeface);
        naughtyTextView2.setTypeface(naughtyTypeface);
        naughtyTextView3.setTypeface(naughtyTypeface);
        naughtyTextView4.setTypeface(naughtyTypeface);
        naughtyTextView5.setTypeface(naughtyTypeface);
        naughtyTextView6.setTypeface(naughtyTypeface);
        naughtyTextView7.setTypeface(naughtyTypeface);
        naughtyTextView8.setTypeface(naughtyTypeface);
        naughtyTextView9.setTypeface(naughtyTypeface);

        //------------------------------------------------------------------------------------------


    }

    public void Restart() {

        this.recreate();

    }


}
