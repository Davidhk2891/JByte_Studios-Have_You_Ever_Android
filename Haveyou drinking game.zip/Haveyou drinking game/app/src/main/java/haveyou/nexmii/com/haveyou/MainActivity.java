package haveyou.nexmii.com.haveyou;

import android.content.Intent;
import android.graphics.Typeface;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;

public class MainActivity extends AppCompatActivity {

    private EditText editTextPlayer1, editTextPlayer2, editTextPlayer3, editTextPlayer4,
    editTextPlayer5, editTextPlayer6, editTextPlayer7, editTextPlayer8, editTextPlayer9;
    private Button nextButton;
    private Button instructions;
    Intent instButtonIntent;
    Intent buttonIntent;
    private TextView firstGuide;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        firstGuide = (TextView) findViewById(R.id.textView);
        instructions = (Button) findViewById(R.id.howToButton);
        editTextPlayer1 = (EditText) findViewById(R.id.player1);
        editTextPlayer2 = (EditText) findViewById(R.id.player2);
        editTextPlayer3 = (EditText) findViewById(R.id.player3);
        editTextPlayer4 = (EditText) findViewById(R.id.player4);
        editTextPlayer5 = (EditText) findViewById(R.id.player5);
        editTextPlayer6 = (EditText) findViewById(R.id.player6);
        editTextPlayer7 = (EditText) findViewById(R.id.player7);
        editTextPlayer8 = (EditText) findViewById(R.id.player8);
        editTextPlayer9 = (EditText) findViewById(R.id.player9);
        nextButton = (Button) findViewById(R.id.nextButton);

        Typeface myTypeFace = Typeface.createFromAsset(getAssets(), "coolfont.ttf");
        firstGuide.setTypeface(myTypeFace);
        nextButton.setTypeface(myTypeFace);
        instructions.setTypeface(myTypeFace);

//--------------ORI'S CHUNK_------------------------------------------------------------------------
//        EditText theArr[] = new EditText[]{
//
//                editTextPlayer1, editTextPlayer2, editTextPlayer3,
//                editTextPlayer4, editTextPlayer5, editTextPlayer6,
//                editTextPlayer7, editTextPlayer8, editTextPlayer9
//
//        };
//
//        Bundle b = getIntent().getExtras();
//        int num = b.getInt("numberOfPlayers");
//
//        for(int i = num; i < theArr.length; i++) {
//            theArr[i].setVisibility(View.INVISIBLE);
//        }
//--------------------------------------------------------------------------------------------------

        nextButton.setOnClickListener(new View.OnClickListener(){

            @Override
            public void onClick(View v) {
                //player 1 button input

                String player1name = editTextPlayer1.getText().toString();
                String player2name = editTextPlayer2.getText().toString();
                String player3name = editTextPlayer3.getText().toString();
                String player4name = editTextPlayer4.getText().toString();
                String player5name = editTextPlayer5.getText().toString();
                String player6name = editTextPlayer6.getText().toString();
                String player7name = editTextPlayer7.getText().toString();
                String player8name = editTextPlayer8.getText().toString();
                String player9name = editTextPlayer9.getText().toString();

                if (player1name.isEmpty() || player2name.isEmpty()){

                    Toast.makeText(getApplicationContext(), "At least 2 people need to play...c'mon... you need friends for this game"
                    , Toast.LENGTH_LONG).show();

                }else {

                    buttonIntent = new Intent(MainActivity.this, CategorieActivity.class);
                    buttonIntent.putExtra("player1Name", player1name);
                    buttonIntent.putExtra("player2Name", player2name);
                    buttonIntent.putExtra("player3Name", player3name);
                    buttonIntent.putExtra("player4Name", player4name);
                    buttonIntent.putExtra("player5Name", player5name);
                    buttonIntent.putExtra("player6Name", player6name);
                    buttonIntent.putExtra("player7Name", player7name);
                    buttonIntent.putExtra("player8Name", player8name);
                    buttonIntent.putExtra("player9Name", player9name);
                    startActivity(buttonIntent);

                }
            }
        });

        instructions.setOnClickListener(new View.OnClickListener(){

            @Override
            public void onClick(View v) {

                instButtonIntent = new Intent(MainActivity.this, InstructionsActivity.class);
                startActivity(instButtonIntent);
            }
        });


    }
}
