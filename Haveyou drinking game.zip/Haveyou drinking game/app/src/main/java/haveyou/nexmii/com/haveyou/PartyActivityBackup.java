package haveyou.nexmii.com.haveyou;

import android.os.Bundle;
import android.support.v7.app.AppCompatActivity;
import android.view.View;
import android.widget.Button;
import android.widget.ImageButton;
import android.widget.TextView;

import java.util.Random;

public class PartyActivityBackup extends AppCompatActivity {

    private TextView textPartyName1, textPartyName2, textPartyName3, textPartyName4, textPartyName5,
            textPartyName6, textPartyName7, textPartyName8, textPartyName9;

    //----------------------COUNTERS----------------------------------------------------------------
    private Button partyCounterBtn1;
    private Button partyCounterBtn2;
    private Button partyCounterBtn3;
    private Button partyCounterBtn4;
    private Button partyCounterBtn5;
    private Button partyCounterBtn6;
    private Button partyCounterBtn7;
    private Button partyCounterBtn8;
    private Button partyCounterBtn9;
    //---------------------------------
    private TextView partyShowCounter1;
    private TextView partyShowCounter2;
    private TextView partyShowCounter3;
    private TextView partyShowCounter4;
    private TextView partyShowCounter5;
    private TextView partyShowCounter6;
    private TextView partyShowCounter7;
    private TextView partyShowCounter8;
    private TextView partyShowCounter9;
    //----------------------------------------------------------------------------------------------

    //textPartyName1, textPartyName2, textPartyName3, textPartyName4, textPartyName5, textPartyName6,
    //textPartyName7, textPartyName8, textPartyName9,
    //----------------------------------------------------------------------------------------------

    private ImageButton mainBtnQuestion;
    private ImageButton mrRefresha;
    private TextView questionTextView;

    final String[] partyQuestions = {

            "broken something, like a window, and ran away?",
            "went sky diving, bungee jumping, or para-sailing?",
            "talked on the phone for more than two hours?",
            "gotten lost in an amusement park or on vacation?",
            "had a friend who shared the same birthday as you?",
            "been out in the rain and really enjoyed it?",
            "had something embarrassing happen to you?",
            "had a near-death experience?",
            "gotten in trouble at school or at church?",
            "helped someone who was in danger?",
            "worn the same underwear two days in a row?",
            "drank soda pop, laughed, and had it come out your nose?",
            "regifted something that you received as a gift?",
            "went camping in a tent?",
            "had your cell phone ring at an embarrassing moment ?",
            "sung karaoke, or did a lip-sync song?",
            "seen a human baby, or a baby animal be born?",
            "had to get stitches?",
            "paid for a stranger’s meal or drink, without them knowing it was you?",
            "stayed in your pajamas all day long?",
            "climbed a tree, or went up on a roof and couldn’t get down?",
            "done a belly-flop off a diving board?",
            "held a butterfly or another insect in your hand?",
            "found a wallet or a money that someone dropped?",
            "ridden a ride that made you scream with fear?",
            "lied to get something cheaper than it was?",
            "won a contest and received a prize?",
            "talked your way out of getting in trouble?",
            "taken a picture of your face on a Xerox machine?",
            "seen an actual tornado (not on TV or in a movie)?",
            "been water skiing or snow skiing?",
            "met a famous person or a celebrity?"

    };

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_party);
        //------------------------------------------------------------------------------------------
        mainBtnQuestion = (ImageButton) findViewById(R.id.buttonHaveYou);
        mrRefresha = (ImageButton) findViewById(R.id.refreshButtonId);
        questionTextView = (TextView) findViewById(R.id.textView5);
        //------------------------------------------------------------------------------------------

        textPartyName1 = (TextView) findViewById(R.id.partyName1);
        textPartyName2 = (TextView) findViewById(R.id.partyName2);
        textPartyName3 = (TextView) findViewById(R.id.partyName3);
        textPartyName4 = (TextView) findViewById(R.id.partyName4);
        textPartyName5 = (TextView) findViewById(R.id.partyName5);
        textPartyName6 = (TextView) findViewById(R.id.partyName6);
        textPartyName7 = (TextView) findViewById(R.id.partyName7);
        textPartyName8 = (TextView) findViewById(R.id.partyName8);
        textPartyName9 = (TextView) findViewById(R.id.partyName9);

        Bundle partyExtras = getIntent().getExtras();
        String textParty1 = partyExtras.getString("partyPlayer1");
        String textParty2 = partyExtras.getString("partyPlayer2");
        String textParty3 = partyExtras.getString("partyPlayer3");
        String textParty4 = partyExtras.getString("partyPlayer4");
        String textParty5 = partyExtras.getString("partyPlayer5");
        String textParty6 = partyExtras.getString("partyPlayer6");
        String textParty7 = partyExtras.getString("partyPlayer7");
        String textParty8 = partyExtras.getString("partyPlayer8");
        String textParty9 = partyExtras.getString("partyPlayer9");

        textPartyName1.setText(textParty1);
        textPartyName2.setText(textParty2);
        textPartyName3.setText(textParty3);
        textPartyName4.setText(textParty4);
        textPartyName5.setText(textParty5);
        textPartyName6.setText(textParty6);
        textPartyName7.setText(textParty7);
        textPartyName8.setText(textParty8);
        textPartyName9.setText(textParty9);


        //------------------------------------------------------------------------------------------

        mainBtnQuestion.setOnClickListener(new View.OnClickListener(){

            @Override
            public void onClick(View v) {

                Random mrRandom = new Random();

                int partyRandomNumber = mrRandom.nextInt(partyQuestions.length);

                questionTextView.setText(partyQuestions[partyRandomNumber]);

            }
        });

        mrRefresha.setOnClickListener(new View.OnClickListener(){

            @Override
            public void onClick(View v) {

                Restart();

            }
        });
//--------------------------------------------------------------------------------------------------
        partyCounterBtn1 = (Button) findViewById(R.id.partyCounterButton1);
        partyCounterBtn2 = (Button) findViewById(R.id.partyCounterButton2);
        partyCounterBtn3 = (Button) findViewById(R.id.partyCounterButton3);
        partyCounterBtn4 = (Button) findViewById(R.id.partyCounterButton4);
        partyCounterBtn5 = (Button) findViewById(R.id.partyCounterButton5);
        partyCounterBtn6 = (Button) findViewById(R.id.partyCounterButton6);
        partyCounterBtn7 = (Button) findViewById(R.id.partyCounterButton7);
        partyCounterBtn8 = (Button) findViewById(R.id.partyCounterButton8);
        partyCounterBtn9 = (Button) findViewById(R.id.partyCounterButton9);
        //------------------------------------------------------------------
        partyShowCounter1 = (TextView) findViewById(R.id.ptTextCounter1);
        partyShowCounter2 = (TextView) findViewById(R.id.ptTextCounter2);
        partyShowCounter3 = (TextView) findViewById(R.id.ptTextCounter3);
        partyShowCounter4 = (TextView) findViewById(R.id.ptTextCounter4);
        partyShowCounter5 = (TextView) findViewById(R.id.ptTextCounter5);
        partyShowCounter6 = (TextView) findViewById(R.id.ptTextCounter6);
        partyShowCounter7 = (TextView) findViewById(R.id.ptTextCounter7);
        partyShowCounter8 = (TextView) findViewById(R.id.ptTextCounter8);
        partyShowCounter9 = (TextView) findViewById(R.id.ptTextCounter9);
//--------------------------------------------------------------------------------------------------

//--N-1---------------------------------------------------------------------------------------------
        if (textPartyName1.length() > 0) {

            partyCounterBtn1.setOnClickListener(new View.OnClickListener(){
                int partyCounter = 0;
                @Override
                public void onClick(View v) {

                    partyCounter++;
                    partyShowCounter1.setText(String.valueOf(partyCounter));

                }
            });

        }else if(textPartyName1.length() == 0) {

            partyCounterBtn1.setVisibility(View.INVISIBLE);
            partyShowCounter1.setVisibility(View.INVISIBLE);

        }
//--------------------------------------------------------------------------------------------------

//--N-2---------------------------------------------------------------------------------------------
        if (textPartyName2.length() > 0) {

            partyCounterBtn2.setOnClickListener(new View.OnClickListener(){
                int partyCounter = 0;
                @Override
                public void onClick(View v) {

                    partyCounter++;
                    partyShowCounter2.setText(String.valueOf(partyCounter));

                }
            });

        }else if(textPartyName2.length() == 0) {

            partyCounterBtn2.setVisibility(View.INVISIBLE);
            partyShowCounter2.setVisibility(View.INVISIBLE);

        }
//--------------------------------------------------------------------------------------------------

//--N-3---------------------------------------------------------------------------------------------
        if (textPartyName3.length() > 0) {

            partyCounterBtn3.setOnClickListener(new View.OnClickListener(){
                int partyCounter = 0;
                @Override
                public void onClick(View v) {

                    partyCounter++;
                    partyShowCounter3.setText(String.valueOf(partyCounter));

                }
            });

        }else if(textPartyName3.length() == 0) {

            partyCounterBtn3.setVisibility(View.INVISIBLE);
            partyShowCounter3.setVisibility(View.INVISIBLE);

        }
//--------------------------------------------------------------------------------------------------

//--N-4---------------------------------------------------------------------------------------------
        if (textPartyName4.length() > 0) {

            partyCounterBtn4.setOnClickListener(new View.OnClickListener(){
                int partyCounter = 0;
                @Override
                public void onClick(View v) {

                    partyCounter++;
                    partyShowCounter4.setText(String.valueOf(partyCounter));

                }
            });

        }else if(textPartyName4.length() == 0) {

            partyCounterBtn4.setVisibility(View.INVISIBLE);
            partyShowCounter4.setVisibility(View.INVISIBLE);

        }
//--------------------------------------------------------------------------------------------------

//--N-5---------------------------------------------------------------------------------------------
        if (textPartyName5.length() > 0) {

            partyCounterBtn5.setOnClickListener(new View.OnClickListener(){
                int partyCounter = 0;
                @Override
                public void onClick(View v) {

                    partyCounter++;
                    partyShowCounter5.setText(String.valueOf(partyCounter));

                }
            });

        }else if(textPartyName5.length() == 0) {

            partyCounterBtn5.setVisibility(View.INVISIBLE);
            partyShowCounter5.setVisibility(View.INVISIBLE);

        }
//--------------------------------------------------------------------------------------------------

//--N-6---------------------------------------------------------------------------------------------
        if (textPartyName6.length() > 0) {

            partyCounterBtn6.setOnClickListener(new View.OnClickListener(){
                int partyCounter = 0;
                @Override
                public void onClick(View v) {

                    partyCounter++;
                    partyShowCounter6.setText(String.valueOf(partyCounter));

                }
            });

        }else if(textPartyName6.length() == 0) {

            partyCounterBtn6.setVisibility(View.INVISIBLE);
            partyShowCounter6.setVisibility(View.INVISIBLE);

        }
//--------------------------------------------------------------------------------------------------

//--N-7---------------------------------------------------------------------------------------------
        if (textPartyName7.length() > 0) {

            partyCounterBtn7.setOnClickListener(new View.OnClickListener(){
                int partyCounter = 0;
                @Override
                public void onClick(View v) {

                    partyCounter++;
                    partyShowCounter7.setText(String.valueOf(partyCounter));

                }
            });

        }else if(textPartyName7.length() == 0) {

            partyCounterBtn7.setVisibility(View.INVISIBLE);
            partyShowCounter7.setVisibility(View.INVISIBLE);

        }
//--------------------------------------------------------------------------------------------------

//--N-8---------------------------------------------------------------------------------------------
        if (textPartyName8.length() > 0) {

            partyCounterBtn8.setOnClickListener(new View.OnClickListener(){
                int partyCounter = 0;
                @Override
                public void onClick(View v) {

                    partyCounter++;
                    partyShowCounter8.setText(String.valueOf(partyCounter));

                }
            });

        }else if(textPartyName8.length() == 0) {

            partyCounterBtn8.setVisibility(View.INVISIBLE);
            partyShowCounter8.setVisibility(View.INVISIBLE);

        }
//--------------------------------------------------------------------------------------------------

//--N-9---------------------------------------------------------------------------------------------
        if (textPartyName9.length() > 0) {

            partyCounterBtn9.setOnClickListener(new View.OnClickListener(){
                int partyCounter = 0;
                @Override
                public void onClick(View v) {

                    partyCounter++;
                    partyShowCounter9.setText(String.valueOf(partyCounter));

                }
            });

        }else if(textPartyName9.length() == 0) {

            partyCounterBtn9.setVisibility(View.INVISIBLE);
            partyShowCounter9.setVisibility(View.INVISIBLE);

        }
//--------------------------------------------------------------------------------------------------

    }

    public void Restart() {

        this.recreate();

    }
}
