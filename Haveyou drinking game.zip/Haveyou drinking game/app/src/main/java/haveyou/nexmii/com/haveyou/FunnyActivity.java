package haveyou.nexmii.com.haveyou;

import android.content.Intent;
import android.graphics.Typeface;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.ImageButton;
import android.widget.TextView;

import java.util.Random;


public class FunnyActivity extends AppCompatActivity {

    private TextView funnyTextView1, funnyTextView2, funnyTextView3, funnyTextView4, funnyTextView5,
            funnyTextView6, funnyTextView7, funnyTextView8, funnyTextView9;

    private Button theFunnyButton;
    private TextView theFunnyTextView;
    private ImageButton funnyRefreshment;
    private TextView mainTitleFunny;
    private Button funnyGuide;
    Intent funnyGuideIntent;
    //----------------------------------------------------------------------------------------------

    private Button funnyCounterBtn1, funnyCounterBtn2, funnyCounterBtn3, funnyCounterBtn4, funnyCounterBtn5,
            funnyCounterBtn6, funnyCounterBtn7, funnyCounterBtn8, funnyCounterBtn9;
    private TextView funnyShowCounter1, funnyShowCounter2, funnyShowCounter3, funnyShowCounter4,
            funnyShowCounter5, funnyShowCounter6, funnyShowCounter7, funnyShowCounter8, funnyShowCounter9;
    //funnyTextView1, funnyTextView2, funnyTextView3, funnyTextView4, funnyTextView5, funnyTextView6,
    //funnyTextView7, funnyTextView8, funnyTextView9
    //----------------------------------------------------------------------------------------------

    final String[] funnyQuestions = {

            "been showering and had someone throw ice water on you?",
            "tried to burp the alphabet?",
            "been in an earthquake or a tornado?",
            "gone skinny dipping?",
            "fallen down the stairs?",
            "lied about not doing something you were suppose to do?",
            "swam in ice cold water?",
            "eaten frog legs, or some other strange food?",
            "toilet-papered someone’s house?",
            "done something dumb while camping?",
            "faked being sick to stay home and skip school or work?",
            "pretended to speak a foreign language you don’t know?",
            "lost part of your bathing suit?",
            "gone on a “bad” blind date?",
            "have you ever made up a story to get out of a traffic ticket?",
            "won a contest?",
            "made a prank phone call?",
            "eaten a whole cake or a pizza yourself?",
            "seen the same movie more than twice at a theater?",
            "played a trick on someone, or had someone play a trick on you?",
            "skipped a class or a whole day of school?",
            "thrown up on an airplane or on a boat?",
            "been kicked or bitten by an animal?",
            "sung in the shower or on the toilet?",
            "locked your keys in the car, or have been locked out of your house?",
            "spied on your neighbors?",
            "shared food with your dog or cat?",
            "dyed your hair, and it didn’t turn out well?",
            "been sky diving or scuba diving?",
            "had food or a drink spilled on you at a restaurant or party?",
            "ridden on a cow, an elephant, or some strange animal?",
            "sung in front of people by yourself?",
            "had a blow-out tire while driving?",
            "gotten lost at an amusement park or on a vacation?",
            "had to run to save my life",
            "Bit my tongue",
            "been to a country in Africa",
            "been electrocuted",
            "ridden an animal",
            "accidentally sent someone to the hospital",
            "dyed my hair a crazy color",
            "read a whole novel in one day",
            "been without heat for a winter or AC for a summer",
            "worn glasses without lenses",
            "gone scuba diving",
            "gone vegan",
            "walked out of a movie because it was bad",
            "broken a bone",
            "thrown up on a roller coaster",
            "tried to cut my own hair",
            "gone hunting",
            "thrown something into a TV or computer screen and broke it",
            "been to a country in Asia",
            "worked with someone I hated with burning passion",
            "completely forgot my lines in a play",
            "had a bad fall because I was walking and texting",
            "injured myself while trying to impress a girl or boy",
            "taken food out of a trash can and eaten it",
            "flirted my way out of a speeding ticket",
            "taken part in a talent show",
            "made money by performing on the street",
            "Fought in the street",
            "been on TV or the radio",
            "Fallen asleep on the bus and I’ve passed my station",
            "Been in love with my teacher in college",
            "Been robbed",
            "Received a serenade",
            "Done a handstand with one hand",
            "Really liked a song by Justin Bieber",
            "made fun of someone",
            "had a bad allergic reaction",
            "been in an embarrassing video that was uploaded to YouTube",
            "Seen a topless on the beach",
            "thought I was going to drown",
            "worked at a fast food restaurant",
            "fainted",
            "Stole something with a higher value than $10",
            "bragged about something I have not done",
            "Been stuck in a lift",
            "danced in an elevator with people in it",
            "cried in public because of a song",
            "Lied to my parents about where I’m going",
            "Finished an entire jaw breaker",
            "Been in handcuffs",
            "gotten stitches",
            "fallen in love at first sight",
            "had a paranormal experience",
            "woken up and couldn’t move",
            "Fallen asleep in the cinema",
            "been so sun burnt I couldn’t wear a shirt",
            "ruined someone else’s vacation",
            "pressed send and then immediately regretted it",
            "walked for more than six hours",
            "seen an alligator or crocodile in the wild"

    };

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_funny);


//--------------------------------------------------------------------------------------------------
        theFunnyButton = (Button) findViewById(R.id.buttonHaveYou);
        theFunnyTextView = (TextView) findViewById(R.id.textView5);
        funnyRefreshment = (ImageButton) findViewById(R.id.refreshButtonId);
//--------------------------------------------------------------------------------------------------

        mainTitleFunny = (TextView) findViewById(R.id.mainFunnyTitle);
        funnyGuide = (Button) findViewById(R.id.howToFunny);
        funnyTextView1 = (TextView) findViewById(R.id.funnyName1);
        funnyTextView2 = (TextView) findViewById(R.id.funnyName2);
        funnyTextView3 = (TextView) findViewById(R.id.funnyName3);
        funnyTextView4 = (TextView) findViewById(R.id.funnyName4);
        funnyTextView5 = (TextView) findViewById(R.id.funnyName5);
        funnyTextView6 = (TextView) findViewById(R.id.funnyName6);
        funnyTextView7 = (TextView) findViewById(R.id.funnyName7);
        funnyTextView8 = (TextView) findViewById(R.id.funnyName8);
        funnyTextView9 = (TextView) findViewById(R.id.funnyName9);

        Bundle funnyExtras = getIntent().getExtras();
        String funnyName1 = funnyExtras.getString("funnyPlayer1");
        String funnyName2 = funnyExtras.getString("funnyPlayer2");
        String funnyName3 = funnyExtras.getString("funnyPlayer3");
        String funnyName4 = funnyExtras.getString("funnyPlayer4");
        String funnyName5 = funnyExtras.getString("funnyPlayer5");
        String funnyName6 = funnyExtras.getString("funnyPlayer6");
        String funnyName7 = funnyExtras.getString("funnyPlayer7");
        String funnyName8 = funnyExtras.getString("funnyPlayer8");
        String funnyName9 = funnyExtras.getString("funnyPlayer9");

        funnyTextView1.setText(funnyName1);
        funnyTextView2.setText(funnyName2);
        funnyTextView3.setText(funnyName3);
        funnyTextView4.setText(funnyName4);
        funnyTextView5.setText(funnyName5);
        funnyTextView6.setText(funnyName6);
        funnyTextView7.setText(funnyName7);
        funnyTextView8.setText(funnyName8);
        funnyTextView9.setText(funnyName9);

        //------------------------------------------------------------------------------------------

        theFunnyButton.setOnClickListener(new View.OnClickListener(){

            @Override
            public void onClick(View v) {

                Random mrRandom = new Random();

                int funnyRandomNumber = mrRandom.nextInt(funnyQuestions.length);

                theFunnyTextView.setText(funnyQuestions[funnyRandomNumber]);

            }
        });

        funnyRefreshment.setOnClickListener(new View.OnClickListener(){

            @Override
            public void onClick(View v) {

                Restart();

            }
        });
        //-----------------------------COUNTER BUTTONS AND DISPLAY----------------------------------
        //-----------------------------------------------------------------------
        funnyCounterBtn1 = (Button) findViewById(R.id.counterButton1);
        funnyCounterBtn2 = (Button) findViewById(R.id.counterButton2);
        funnyCounterBtn3 = (Button) findViewById(R.id.counterButton3);
        funnyCounterBtn4 = (Button) findViewById(R.id.counterButton4);
        funnyCounterBtn5 = (Button) findViewById(R.id.counterButton5);
        funnyCounterBtn6 = (Button) findViewById(R.id.counterButton6);
        funnyCounterBtn7 = (Button) findViewById(R.id.counterButton7);
        funnyCounterBtn8 = (Button) findViewById(R.id.counterButton8);
        funnyCounterBtn9 = (Button) findViewById(R.id.counterButton9);
        //----------------------------------------------------------------------
        funnyShowCounter1 = (TextView) findViewById(R.id.textCounter1);
        funnyShowCounter2 = (TextView) findViewById(R.id.textCounter2);
        funnyShowCounter3 = (TextView) findViewById(R.id.textCounter3);
        funnyShowCounter4 = (TextView) findViewById(R.id.textCounter4);
        funnyShowCounter5 = (TextView) findViewById(R.id.textCounter5);
        funnyShowCounter6 = (TextView) findViewById(R.id.textCounter6);
        funnyShowCounter7 = (TextView) findViewById(R.id.textCounter7);
        funnyShowCounter8 = (TextView) findViewById(R.id.textCounter8);
        funnyShowCounter9 = (TextView) findViewById(R.id.textCounter9);
        //----------------------------------------------------------------------
//--------------------------------------------------------------------------------------------------

//------TO INSTRUCTIONS-----------------------------------------------------------------------------

        funnyGuide.setOnClickListener(new View.OnClickListener(){

            @Override
            public void onClick(View v) {

                funnyGuideIntent = new Intent(FunnyActivity.this,InstructionsActivity.class);
                startActivity(funnyGuideIntent);

            }
        });

//N-1-----------------------------------------------------------------------------------------------

        if (funnyTextView1.length() > 0) {

                funnyCounterBtn1.setOnClickListener(new View.OnClickListener(){
                    int funnyCounter = 0;
                    @Override
                    public void onClick(View v) {

                         funnyCounter++;

                        funnyShowCounter1.setText(String.valueOf(funnyCounter));

                    }
                });

        } else if(funnyTextView1.length() == 0){

            funnyCounterBtn1.setVisibility(View.INVISIBLE);
            funnyShowCounter1.setVisibility(View.INVISIBLE);

        }
//--------------------------------------------------------------------------------------------------

//N-2-----------------------------------------------------------------------------------------------

        if (funnyTextView2.length() > 0) {

            funnyCounterBtn2.setOnClickListener(new View.OnClickListener(){
                int funnyCounter = 0;
                @Override
                public void onClick(View v) {

                    funnyCounter++;

                    funnyShowCounter2.setText(String.valueOf(funnyCounter));

                }
            });

        } else if(funnyTextView2.length() == 0){

            funnyCounterBtn2.setVisibility(View.INVISIBLE);
            funnyShowCounter2.setVisibility(View.INVISIBLE);

        }
//--------------------------------------------------------------------------------------------------

//N-3-----------------------------------------------------------------------------------------------

        if (funnyTextView3.length() > 0) {

            funnyCounterBtn3.setOnClickListener(new View.OnClickListener(){
                int funnyCounter = 0;
                @Override
                public void onClick(View v) {

                    funnyCounter++;

                    funnyShowCounter3.setText(String.valueOf(funnyCounter));

                }
            });

        } else if(funnyTextView3.length() == 0){

            funnyCounterBtn3.setVisibility(View.INVISIBLE);
            funnyShowCounter3.setVisibility(View.INVISIBLE);

        }
//--------------------------------------------------------------------------------------------------

//N-4-----------------------------------------------------------------------------------------------

        if (funnyTextView4.length() > 0) {

            funnyCounterBtn4.setOnClickListener(new View.OnClickListener(){
                int funnyCounter = 0;
                @Override
                public void onClick(View v) {

                    funnyCounter++;

                    funnyShowCounter4.setText(String.valueOf(funnyCounter));

                }
            });

        } else if(funnyTextView4.length() == 0){

            funnyCounterBtn4.setVisibility(View.INVISIBLE);
            funnyShowCounter4.setVisibility(View.INVISIBLE);

        }
//--------------------------------------------------------------------------------------------------

//N-5-----------------------------------------------------------------------------------------------

        if (funnyTextView5.length() > 0) {

            funnyCounterBtn5.setOnClickListener(new View.OnClickListener(){
                int funnyCounter = 0;
                @Override
                public void onClick(View v) {

                    funnyCounter++;

                    funnyShowCounter5.setText(String.valueOf(funnyCounter));

                }
            });

        } else if(funnyTextView5.length() == 0){

            funnyCounterBtn5.setVisibility(View.INVISIBLE);
            funnyShowCounter5.setVisibility(View.INVISIBLE);

        }
//--------------------------------------------------------------------------------------------------

//N-6-----------------------------------------------------------------------------------------------

        if (funnyTextView6.length() > 0) {

            funnyCounterBtn6.setOnClickListener(new View.OnClickListener(){
                int funnyCounter = 0;
                @Override
                public void onClick(View v) {

                    funnyCounter++;

                    funnyShowCounter6.setText(String.valueOf(funnyCounter));

                }
            });

        } else if(funnyTextView6.length() == 0){

            funnyCounterBtn6.setVisibility(View.INVISIBLE);
            funnyShowCounter6.setVisibility(View.INVISIBLE);

        }
//--------------------------------------------------------------------------------------------------

//N-7-----------------------------------------------------------------------------------------------

        if (funnyTextView7.length() > 0) {

            funnyCounterBtn7.setOnClickListener(new View.OnClickListener(){
                int funnyCounter = 0;
                @Override
                public void onClick(View v) {

                    funnyCounter++;

                    funnyShowCounter7.setText(String.valueOf(funnyCounter));

                }
            });

        } else if(funnyTextView7.length() == 0){

            funnyCounterBtn7.setVisibility(View.INVISIBLE);
            funnyShowCounter7.setVisibility(View.INVISIBLE);

        }
//--------------------------------------------------------------------------------------------------

//N-8-----------------------------------------------------------------------------------------------

        if (funnyTextView8.length() > 0) {

            funnyCounterBtn8.setOnClickListener(new View.OnClickListener(){
                int funnyCounter = 0;
                @Override
                public void onClick(View v) {

                    funnyCounter++;

                    funnyShowCounter8.setText(String.valueOf(funnyCounter));

                }
            });

        } else if(funnyTextView8.length() == 0){

            funnyCounterBtn8.setVisibility(View.INVISIBLE);
            funnyShowCounter8.setVisibility(View.INVISIBLE);

        }
//--------------------------------------------------------------------------------------------------

//N-9-----------------------------------------------------------------------------------------------

        if (funnyTextView9.length() > 0) {

            funnyCounterBtn9.setOnClickListener(new View.OnClickListener(){
                int funnyCounter = 0;
                @Override
                public void onClick(View v) {

                    funnyCounter++;

                    funnyShowCounter9.setText(String.valueOf(funnyCounter));

                }
            });

        } else if(funnyTextView9.length() == 0){

            funnyCounterBtn9.setVisibility(View.INVISIBLE);
            funnyShowCounter9.setVisibility(View.INVISIBLE);

        }
//--------------------------------------------------------------------------------------------------
                               //---------Font------------
        Typeface funnyTypeFace = Typeface.createFromAsset(getAssets(), "coolfont.ttf");

        funnyTextView1.setTypeface(funnyTypeFace);
        funnyTextView2.setTypeface(funnyTypeFace);
        funnyTextView3.setTypeface(funnyTypeFace);
        funnyTextView4.setTypeface(funnyTypeFace);
        funnyTextView5.setTypeface(funnyTypeFace);
        funnyTextView6.setTypeface(funnyTypeFace);
        funnyTextView7.setTypeface(funnyTypeFace);
        funnyTextView8.setTypeface(funnyTypeFace);
        funnyTextView9.setTypeface(funnyTypeFace);
        theFunnyTextView.setTypeface(funnyTypeFace);
        funnyShowCounter1.setTypeface(funnyTypeFace);
        funnyShowCounter2.setTypeface(funnyTypeFace);
        funnyShowCounter3.setTypeface(funnyTypeFace);
        funnyShowCounter4.setTypeface(funnyTypeFace);
        funnyShowCounter5.setTypeface(funnyTypeFace);
        funnyShowCounter6.setTypeface(funnyTypeFace);
        funnyShowCounter7.setTypeface(funnyTypeFace);
        funnyShowCounter8.setTypeface(funnyTypeFace);
        funnyShowCounter9.setTypeface(funnyTypeFace);
        mainTitleFunny.setTypeface(funnyTypeFace);
        theFunnyButton.setTypeface(funnyTypeFace);
        funnyGuide.setTypeface(funnyTypeFace);
//--------------------------------------------------------------------------------------------------
    }

    public void Restart() {

        this.recreate();

    }
}
