package haveyou.nexmii.com.haveyou;

import android.graphics.Typeface;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.widget.TextView;

public class InstructionsActivity extends AppCompatActivity {

    private TextView title;
    private TextView howToPlay;
    private TextView howToPlay2;
    private TextView howToPlay3;
    private TextView howToPlay4;
    private TextView howToPlay5;
    private TextView howToPlay6;
    private TextView howToPlay7;
    private TextView howToPlay8;



    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_instructions);

        title = (TextView) findViewById(R.id.InstructionsTitle);
        howToPlay = (TextView) findViewById(R.id.howToText);
        howToPlay2 = (TextView) findViewById(R.id.howToText2);
        howToPlay3 = (TextView) findViewById(R.id.howToText3);
        howToPlay4 = (TextView) findViewById(R.id.howToText4);
        howToPlay5 = (TextView) findViewById(R.id.howToText5);
        howToPlay6 = (TextView) findViewById(R.id.howToText6);
        howToPlay7 = (TextView) findViewById(R.id.howToText7);
        howToPlay8 = (TextView) findViewById(R.id.howToText8);

        Typeface myTypefatzia = Typeface.createFromAsset(getAssets(), "coolfont.ttf");
        title.setTypeface(myTypefatzia);
        howToPlay.setTypeface(myTypefatzia);
        howToPlay2.setTypeface(myTypefatzia);
        howToPlay3.setTypeface(myTypefatzia);
        howToPlay4.setTypeface(myTypefatzia);
        howToPlay5.setTypeface(myTypefatzia);
        howToPlay6.setTypeface(myTypefatzia);
        howToPlay7.setTypeface(myTypefatzia);
        howToPlay8.setTypeface(myTypefatzia);

    }
}
